#!/bin/bash
echo "resolve.sh start ..."